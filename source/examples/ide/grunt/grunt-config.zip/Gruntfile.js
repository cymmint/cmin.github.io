module.exports = function (grunt) {

    var M = {
        str: function (s) {
            return s < 10 ? '0' + s : s + '';
        },
        ver: function (isMs) { //版本时间
            var D = new Date();
            if (isMs == 1) {
                return '?v=' + D.getTime().toString();
            } else if (isMs == 2) {
                return '?v=' + M.str(D.getFullYear()) + M.str(D.getMonth() + 1) + M.str(D.getDate()) + '_' + M.str(D.getHours()) + M.str(D.getMinutes()) + M.str(D.getSeconds());
            } else {
                return '';
            }
        }
    };

    // 构建任务配置
    grunt.initConfig({

        //读取package.json的内容
        //pkg: grunt.file.readJSON('webProject/WAP/农民通/nmt.json'),
        //pkg: grunt.file.readJSON('webProject/WEB/农民宝/nmb.json'),
        //pkg: grunt.file.readJSON('webProject/WAP/志愿者平台/backer.json'),
        //pkg: grunt.file.readJSON('webProject/WAP/ZJ-Draw/draw.json'),
        //pkg: grunt.file.readJSON('webProject/WEB/Evercore/evercore.json'),
        //pkg: grunt.file.readJSON('weichao.json'),
        //pkg: grunt.file.readJSON('CYC/PCStore/store.json'),
        //pkg: grunt.file.readJSON('CYC/APPWAP2/package.json'),
        //pkg: grunt.file.readJSON('CYC/OS201702/package.json'),
        //pkg: grunt.file.readJSON('cmin-Slider/slider.json'),
        pkg: grunt.file.readJSON('webProject/WEB/OnSkySell/package.json'),

        //注释文件描述
        meta: {
            banner: '/***!\n' +
            ' * <%= pkg.description %> v<%= pkg.version %>\n' +
            ' * Update: <%= grunt.template.today("yyyy-mm-dd HH:MM:ss") %>\n' +
            ' * Author: <%= pkg.author %>\n' +
            ' * Copyright(c) <%= pkg.homepage %>\n' +
            ' */\n'
        },

        //复制文件
        copy: {
            siteRes: {
                files: [{
                    expand: true, //递归查找
                    //flatten: true, //平坦输出
                    cwd: '<%= pkg.file %>/',
                    dest: '<%= pkg.repository %>/',
                    src: ['**/*.html', '**/*.js', '**/*.min.css', '**/*.mp3']
                    //src: ['**/*.html', '**/*.min.js', '**/*.min.css', '**/*.mp3']
                }]
            }
        },

        //压缩js
        uglify: {
            //文件头部输出信息
            options: {
                banner: '<%= meta.banner %>', //添加注释头
                mangleProperties: false, //是否混淆-属性 [慎用，混淆属性后可能后导致某些方法出错]
                mangle: true, //是否混淆-变量名
                drop_console: true, //是否删除console.*
                /*mangle: {
                 except: ['jQuery', 'Backbone'] //这些变量名除外
                 }*/
                beautify: false //格式化JS
            },
            jsCompress: {
                files: [{
                    expand: true, //动态扩展
                    //相对路径
                    cwd: '<%= pkg.file %>/js/', //当前工作路径
                    dest: '<%= pkg.repository %>/js/', //输出目录(直接覆盖)
                    src: ['*.js', '!*.min.js'], //要处理的文件格式 (不压缩 min.js)
                    ext: '.min.js' //目标文件路径中文件的扩展名
                    //extDot: 'first' // 扩展名始于文件名的第一个点号
                }]
            }
        },

        //LESS
        less: {
            compile: {
                expand: true,
                cwd: '<%= pkg.file %>/less/',
                dest: '<%= pkg.repository %>/less/',
                src: ["**/*.less", "!**/var.less", "!**/base.less", "!**/fun.less", "!**/modal.less", "!**/cmin*.less"],
                ext: ".css"
            }
        },

        //压缩css
        cssmin: {
            //文件头部输出信息
            options: {
                banner: '<%= meta.banner %>',
                beautify: {
                    ascii_only: true //中文ascii化，非常有用，防止中文乱码
                },
                compatibility: 'ie8', //设置兼容模式
                noAdvanced: true //取消高级特性
            },
            cssCompress: {
                files: [
                    {
                        expand: true, //动态扩展
                        //flatten: true, //平坦输出
                        //相对路径
                        cwd: '<%= pkg.file %>/css/',
                        dest: '<%= pkg.repository %>/css/',
                        src: ['**/*.css', '!**/*.min.css'],
                        ext: '.min.css', // 等价
                        /*rename: function (dest, src) {
                         var folder = src.substring(0, src.lastIndexOf('/'));
                         var filename = src.substring(src.lastIndexOf('/'), src.length);
                         filename = filename.substring(0, filename.lastIndexOf('.'));
                         var fileresult = dest + folder + filename + '.min.css';
                         grunt.log.writeln("源：" + src + "  处理后文件：" + fileresult);
                         return fileresult;
                         }*/
                    },
                    {
                        expand: true, //动态扩展
                        cwd: '<%= pkg.repository %>/less/',
                        dest: '<%= pkg.repository %>/css/',
                        src: ['**/*.css', '!**/*.min.css'],
                        ext: '.min.css'
                    }
                ]
            }
        },

        //CSS前端添加
        autoprefixer: {
            options: {
                browserslist: ['last 2 versions']
            },
            addPrefix: {
                expand: true,
                cwd: '<%= pkg.repository %>/',
                dest: '<%= pkg.repository %>/',
                src: ['**/*.css']
            }
        },

        //压缩图片
        imagemin: { //NodeJS V5 支持
            static: {
                options: {
                    optimizationLevel: 7, // png图片优化水平，3是默认值，取值区间0-7
                    svgoPlugins: [{removeViewBox: false}],
                    //use: [mozjpeg()]
                }
            },
            dynamic: {
                files: [{
                    expand: true,
                    cwd: '<%= pkg.file %>/',
                    src: ['**/*.{png,jpg,jpeg,gif,webp,svg,ico}'],
                    dest: '<%= pkg.repository %>/'
                }]
            }
        },

        //自动雪碧图
        sprite: {
            options: {
                // sprite背景图源文件夹，只有匹配此路径才会处理，默认 images/slice/
                imagepath: '<%= pkg.repository %>/icons',
                // 映射CSS中背景路径，支持函数和数组，默认为 null
                imagepath_map: null,
                // 雪碧图输出目录，注意，会覆盖之前文件！默认 images/
                spritedest: '<%= pkg.repository %>/images/',
                // 替换后的背景路径，默认 ../images/
                spritepath: '../images/',
                // 各图片间间距，如果设置为奇数，会强制+1以保证生成的2x图片为偶数宽高，默认 0
                padding: 10,
                // 是否使用 image-set 作为2x图片实现，默认不使用
                useimageset: false,
                // 是否以时间戳为文件名生成新的雪碧图文件，如果启用请注意清理之前生成的文件，默认不生成新文件
                newsprite: false,
                // 给雪碧图追加时间戳，默认不追加
                spritestamp: false,
                // 在CSS文件末尾追加时间戳，默认不追加
                cssstamp: false,
                // 默认使用二叉树最优排列算法
                algorithm: 'binary-tree',
                // 默认使用`pngsmith`图像处理引擎 [gm, pngsmith, pixelsmith]
                engine: 'pixelsmith'
            },
            autoSprite: {
                files: [{
                    // 启用动态扩展
                    expand: true,
                    // css文件源的文件夹
                    cwd: '<%= pkg.repository %>/',
                    // 导出css和sprite的路径地址
                    dest: '<%= pkg.repository %>/',
                    // 匹配规则
                    src: ['**/*.min.css'],
                    // 导出的css名
                    ext: '.min.css'
                }]
            }
        },

        //处理html中css、js引入合并问题
        usemin: {
            files: {
                src: '<%= pkg.repository %>/**/*.html'
            },
            options: {
                blockReplacements: {
                    js: function (block) {
                        grunt.log.write(block)
                        return '<script src="' + block.dest + M.ver(0) + '"><\/script>'; //为js标签的定制
                    },
                    css: function (block) {
                        return '<link rel="stylesheet" type="text/css" href="' + block.dest + M.ver(0) + '">'; //为css标签的定制
                    }
                }
            }
        },

        //压缩HTML
        htmlmin: {
            options: {
                removeComments: true,
                collapseWhitespace: true,
                removeCommentsFromCDATA: true,
                collapseBooleanAttributes: true,
                removeAttributeQuotes: true,
                removeRedundantAttributes: true,
                useShortDoctype: true,
                //removeEmptyAttributes: true,
                //removeOptionalTags: true
            },
            html: {
                files: [{
                    expand: true,
                    cwd: '<%= pkg.repository %>/',
                    dest: '<%= pkg.repository %>/',
                    src: ['**/*.html']
                }]
            }
        },

        //清除文件
        clean: {
            start: ['<%= pkg.file %>/Build/'],
            end: [
                '<%= pkg.file %>/less/**/{var,fun,base,base,modal,cmin*}.css',
                '<%= pkg.repository %>/less/',
                //'<%= pkg.repository %>/images/icons/' //如果开启雪碧图
            ]
        },

        //监视
        watch: {
            client: {
                files: ['<%= pkg.file %>/**/*.html', '<%= pkg.file %>/**/*.css', '<%= pkg.file %>/**/*.js', '<%= pkg.file %>/**/images/**/*'],
                options: {
                    livereload: true,
                    debounceDelay: 250
                }
            }
        },

        //配置一个本地Server
        connect: {
            server: {
                options: {
                    port: '<%= pkg.port || 8866 %>', //设置端口号
                    hostname: '<%= pkg.hostname %>',
                    livereload: true
                }
            }
        },

        //自动打开WEB项目
        open: {
            dev: {
                path: '<%= (pkg.hostname || "127.0.0.1") + ":" + (pkg.port || "8866") + "/" + pkg.file %>',
                app: 'chrome.exe'
            },
            build: {
                path: '<%= (pkg.hostname || "127.0.0.1") + ":" + (pkg.port || 8866) + "/" + pkg.repository %>',
                app: 'chrome.exe'
            },
            file: {
                path: '/etc/hosts'
            }
        },

        //打包文件
        compress: {
            main: {
                options: {
                    mode: 'zip',
                    archive: '<%= pkg.name + "-" + grunt.template.today("yyyymmdd_HHMMss") %>.zip'
                },
                files: [{
                    expand: true,
                    cwd: '<%= pkg.repository %>/',
                    src: ['**/*'],
                    dest: '<%= pkg.name %>'
                }]
            }
        }
    });


    // 加载指定插件任务
    grunt.loadNpmTasks('grunt-contrib-copy'); //复制
    grunt.loadNpmTasks('grunt-contrib-uglify'); //JS压缩
    grunt.loadNpmTasks('grunt-contrib-less'); //less简析
    grunt.loadNpmTasks('grunt-contrib-cssmin'); //CSS压缩
    grunt.loadNpmTasks('grunt-autoprefixer'); //CSS前缀添加
    grunt.loadNpmTasks('grunt-contrib-imagemin'); //图像压缩
    grunt.loadNpmTasks('grunt-usemin'); //html中css、js引入合并问题
    grunt.loadNpmTasks('grunt-contrib-htmlmin'); //HTML压缩
    grunt.loadNpmTasks('grunt-css-sprite'); //雪碧图
    grunt.loadNpmTasks('grunt-contrib-clean'); //清除文件

    grunt.loadNpmTasks('grunt-contrib-watch'); //监视
    grunt.loadNpmTasks('grunt-contrib-connect'); //配置一个Server
    grunt.loadNpmTasks('grunt-livereload'); //自动刷新
    grunt.loadNpmTasks('grunt-open'); //打开浏览器

    grunt.loadNpmTasks('grunt-contrib-compress'); //打包文件


    // 默认执行的任务 - 顺序执行
    grunt.registerTask('default', [
        'clean:start',
        "copy",
        //'uglify',
        'less',
        'cssmin',
        'autoprefixer',
        'imagemin',
        "usemin",
        //'sprite',
        //'htmlmin',
        'clean:end'
    ]);

};